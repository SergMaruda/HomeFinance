<html>
<head> 
<meta charset="utf-8">
<title>Транзакции</title> 
 <head>
<link rel="stylesheet" type="text/css" href="mystyle.css">
</head>

</style>
</head>

<body>
<?php include 'transactions.php';?>

</body>
</html> 