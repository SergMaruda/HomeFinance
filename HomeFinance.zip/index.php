<?php
include('header.php');
?>

<div class="leftbar">
  <?php
  include('accounts_status.php');
  ?>
</div >
 
<div >
  <?php
  include('accounts_status_by_currency.php');
  ?>
</div >

 <div class="noleft">
  <?php
  include('transactions.php');
  ?>
</div >

</body>
</html>