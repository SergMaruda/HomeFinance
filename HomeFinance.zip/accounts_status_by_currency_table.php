<?php 

require 'header.php';
include 'accounts_status_by_currency.php';

echo '</body></html>';
?>
